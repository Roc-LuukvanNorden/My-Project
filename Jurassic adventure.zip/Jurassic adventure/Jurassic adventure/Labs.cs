﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Labs
    {
        places places = new places();//makes sure i can use commands from that class in this one 
        Tools Tools= new Tools();//makes sure i can use commands from that class in this one 
        Raptor_Paddock raptor_Paddock = new Raptor_Paddock();//makes sure i can go to a command from that class
        Visitor_Center visitorCenter    = new Visitor_Center();
        
        /// <summary>
        /// this method is the lab location and every option there.
        /// </summary>
        public void Labratory()
        {
            if( visitorCenter.keycard==false)// this if statement checks if the player has collected the needed item to enter this part of the game
            {
                Tools.print("Oh no it looks like you need a keycard to enter the labs. * I will give you a quick hint: go to the Staff room on the north side of the island.(Press any key to continue)");
                Console.ReadKey();//this command makes sure that the next part of the game does'nt load until the player presses any key
                raptor_Paddock.Raptor_Cage();//this command makes the player go back to a different part of the game
            }
            else if(visitorCenter.keycard== true)
            {
                Tools.print("You insert your keycard and enter the labs. You head to your computer to retrieve the data.");
                if (visitorCenter.usb_Stick ==false)//this if statement checks if the player has the needed item to continue the story
                {
                    Tools.print("You feel around for a USB to import the data on but you havent got it, i guess you better look for it.\n *You head back to the raptor paddock.* (Press any key to continue.");
                    Console.ReadKey();
                    raptor_Paddock.Raptor_Cage();


                }
                else if (visitorCenter.usb_Stick == true)
                {
                    Tools.print(" You feel around for a USB to import the data on you find it in your left pocket. \n You insert the USB and import al the data you need. \n * You leave the labs and head back to the raptor paddock.* (Press any key to continue)");
                    Console.ReadKey();
                    raptor_Paddock.Raptor_Cage();
                }
            }
        }


    }
}

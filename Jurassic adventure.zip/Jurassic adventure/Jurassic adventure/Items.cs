﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Items
    {

        public bool keycard;// sets bool keycard on false
        


        public bool binders;//sets bool binders on false
        public bool computer_Data;//sets bool computer data on false
        public bool usb_Stick;//sets bool usb on false
        
    }
}

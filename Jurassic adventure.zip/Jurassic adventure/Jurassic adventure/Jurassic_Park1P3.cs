﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Jurassic_Park1P3
    {
        DNA_Sequence DNA = new DNA_Sequence();
        places Places = new places();
        


        /// <summary>
        /// this method just runs all commands for this part of the game
        /// </summary>

        public void islaSorna()
        {
            string cutScene = File.ReadAllText("Chopper.txt");// i use this command to import the ascii art
            string[] art = cutScene.Split('1');//i use this command to make sure the animation art doesn't stop at a random time in the ascii art
            Console.Write(cutScene[0]);

            for (int i = 0; i < art.Length; i++)//this forloop is used to animate my ascii art
            {
                Console.Clear();
                Console.WriteLine(art[i]);
                Thread.Sleep(1000);//this command is used to put a 1 second gap between each frame so that it isn't to fast
                Console.Clear();//this command delets the earlier tekst or frame's so that it doesn't stack on top of eachother
            }
            Console.WriteLine("* You arive at Isla-Sorna*\n John Hammond: Welcome to Isla-Sorna, now that we are here I can show you what your job is. \n *You follow Hammond into a small office building.\n John Hammond: Well Henry, I will keep it simple, what InGen and myself are planning to do is to build a zoo with extinct prehistoric animals. Only one problem, they don't exist. \n You: I believe that is why they are called extinct....\n John Hammond: Obviously but my scientists have found a way to clone them. \n You: Clone them? But you need quite some DNA for that it might be possible with recent extinct animals but still\n. What kind of animals are you planning to clone anyway?\n John Hammond: Dinosaurs. \n You: Dinosaurs?! How do you even think that is possible! It is impossible to get even a little bit off Dino-Dna!\n John Hammond: That is what everyone thought yes, but my scientists have found a way to get the Dna. \n You: How? \n John Hammond: I will show you.\n *You follow John Hammond to a lab with a lot of yellow stones, computers and special tools.* \n John Hammond: Do you know what these yellow rocks are?\n You: Yes that is amber but i haven't got the slightest idea what that has to do with this. \n John Hammond: Let me explain millions of years ago there were muscito's just like today and sometimes they would suck the blood off dinosaurs and later get stuck in the sap of a tree. Well, right here we have the equipment to collect the blood from the muscitio's and Bingo, Dino-Dna.\n You: Okay but still that DNA is so old it must be full of gaps. \n John Hammond: That is correct, that is why here we fill the gaps with another type of DNA only problem is, we don't know what DNA type to use and we don't have enough people who understand the logic and machines we use, but now we have you on the team and according to your university you where splendid on the field of DNA. \n You: Well yeah that is true, but I have no idea which DNA type i need to use to complete these DNA strengs. \n John Hammond: Oh not to worry we have narrowed it down to four DNA types. Well I, think I have explained everything I will leave you to it good luck.\n *Hammond leaves*\n\n Press any key to continue.");// this command is just to output the text

            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("You: Great now I need to figure out what to do, maybe looking arround can help me. (Press any key to continue.)");
            Console.ReadKey();
            office();
        }
        /// <summary>
        /// this method is a different part of the game, and just uses all commands here
        /// </summary>
        public void office()
        {
            do//this do loop repeats everything inside it until all conditions in the additonal while loop are true
            {
                string officeChoices;//this string is used to allow the player to make the choice where to look first

                Console.WriteLine("* You look around and see a desk a binder and a small cabinet. Where do you whant to go.*");
                officeChoices = Console.ReadLine();


                if (officeChoices.ToLower() == "desk")
                {

                    Console.WriteLine("* You look on the desk, on the desk stands a computer screen with laying next to it a binder.*");

                    
                    Places.desk = true;//sets this conditoin to true when the player typed desk



                }
                else if (officeChoices.ToLower() == "binder")
                {

                    Console.WriteLine("* You look in the binder and find a notepad, the computer password and some more information.*");

                    
                    Places.binder = true;//sets this conditoin to true when the player typed binder



                }
                else if (officeChoices.ToLower() == "cabinet")
                {

                    Console.WriteLine("*You go to the cabinet and open it. in the cabinet are some empty folders and office tools like a stapeler and paperclips.*");

                   
                    Places.cabinet = true;//sets this conditoin to true when the player typed cabinet


                }
                else
                {
                    Console.WriteLine("Sorry I didn't understand that");
                    Console.ReadKey();
                    Console.WriteLine("* You look around and see a desk a binder and a small cabinet. Where do you whant to go.*");
                    continue;
                }

            }
            while ((Places.desk == false || Places.binder == false || Places.cabinet == false));




            if (Places.desk == true && Places.binder == true && Places.cabinet == true)//when all the conditions are set to true the game continues
            {

                DNA.DNA();




            }

        }
    }







}


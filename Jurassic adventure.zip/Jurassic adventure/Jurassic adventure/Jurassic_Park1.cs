﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Jurassic_Park1
    {
        Tools T = new Tools();
        /// <summary>
        /// starts the main game
        /// </summary>
        public void game()
        {

            Console.Clear();
            Console.WriteLine("before we begin a little more backstory about Doctor Wu. \n Henry Wu is a scientist in the field of biogenetics with a PhD from Oklahoma State University. Now we can begin! Press any key to start the game.");
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("*You are in your living room when you hear something fall trough your mailbox.*");
            choice01();

        }
        /// <summary>
        /// first choice moment in the game
        /// </summary>
        public void choice01()
        {
            string userChoice01;
            string userchoice02;
            string userchoice03;
            Console.WriteLine("*You can look around your house or check the mail.*");
            userChoice01 = Console.ReadLine();
            if (userChoice01.ToLower() == "look around")
            {
                roomChoices();

            }
            else if (userChoice01 == "check mail")
            {
                Console.WriteLine("*You seem to have gotten a letter from a company named: InGen.*");
                Console.WriteLine("Do you want to read the letter or do you want to put it away?");
                userchoice02 = Console.ReadLine();
                if (userchoice02.ToLower() == "read")//to lower is used to make sure that if the player accidently uses caps lock the answer wont give a error
                {
                    Console.Clear();
                    //backslash n is used to add a extra line between the output
                    T.print("*Dear Dr.Wu, \n let me introduce myself, I am John Hammond. I have a company named InGen that specilises in biogenetic research, but I have a small problem I don't have enough scientists specilised in biogenetics, \n so I asked around university's for students they recomended. that is how I found you. \n So let me get to the point I want to hire you as my head scientist, please consider this offer, when you reached your dessicion please contact us at: WorkAtInGen@Gmail.com.*", 80);
                    choice03();

                }
                else if (userchoice02.ToLower() == "put it away")
                {
                    Console.WriteLine("You put away the letter and forget about it.");
                    System.Environment.Exit(0);

                }
                else
                {
                    Console.WriteLine("Sorry i didn't understand you can you try aigan?");
                    Console.Clear();
                    game();
                }

            }
            else
            {
                Console.WriteLine("Sorry i didn't understand you can you try aigan?");
                Console.Clear();
                choice01();


            }

        }
        /// <summary>
        /// this method is used when the player chooses to read a letter
        /// </summary>
        public void choice03()
        {
            string userChoice03;
            Console.WriteLine(" ");
            Console.WriteLine("Are you taking the job offer? (yes)...(no)");
            userChoice03 = Console.ReadLine();
            if (userChoice03.ToLower() == "yes")
            {
                Console.Clear();
                Console.WriteLine(" You: (Well I don't have any work right now might as well take the job.)");
                Console.WriteLine("I should probably contact them.");
                Console.WriteLine("You go to your computer and sent your response in a mail, then \n you shut it of and go to bed.\n When you wake up you check your mail and see you have a respons:");
               
                T.print("Dear Dr.Wu,\n thank you for your quick response.If it is possible for you please visit us at our main location in Costa Rica we will pay for your costs.\n sincerly John Hammond", 80);
                
                Console.WriteLine("You: Well better get a ticket to go to Costa Rica");
                Console.WriteLine("Press any button to continue.");
                Console.ReadKey();
            }
            else if (userChoice03.ToLower() == "no")
            {
                Console.WriteLine("You dont take the job.");
                System.Environment.Exit(0);
            }
        }
        /// <summary>
        /// this method is used when the player chooses to look around the house
        /// </summary>
        public void roomChoices()
        {
            string roomChoice;



            Console.WriteLine("You are in the living room, you can go to the kitchen or the hallway. Where do you want to go?");
            roomChoice = Console.ReadLine();
            if (roomChoice.ToLower() == "kitchen")
            {
                kitchen();
            }
            else if (roomChoice.ToLower() == "hallway")
            {

                hallway();
            }
            else
            {
                Console.WriteLine("Sorry you cant go there.");
                roomChoices();

            }



        }
        /// <summary>
        /// this is the method that is used when the player enters the hallway
        /// </summary>
        public void hallway()
        {
            string mailChoice;
            string hallwayChoice;
            Console.WriteLine("You are in the hallway. You can check the mail, go to the living room or go upstairs");
            hallwayChoice = Console.ReadLine();
            if (hallwayChoice.ToLower() == "check te mail")
            {

                Console.WriteLine("You seem to have gotten a letter from a company named: InGen.");
                Console.WriteLine("Do you want to read the letter or do you want to put it away?");
                mailChoice = Console.ReadLine();
                if (mailChoice.ToLower() == "read")
                {
                    Console.Clear();
                    T.print("Dear Dr.Wu, \n let me introduce myself, I am John Hammond. I have a company named InGen that specilises in biogenetic research, but I have a small problem I don't have enough sientists specilised in biogenetics, \n so I asked around university's for students they reccomended. that is how I found you. \n So let me get to the point I want to hire you as my head sientist, please consider this offer, when you reached you're dessicion please contact us.", 80);
                    choice03();


                }


            }
            else if (hallwayChoice.ToLower() == "living room")
            {
                roomChoices();
            }
            else if (hallwayChoice.ToLower() == "go upstairs")
            {
                upstairs();
            }



        }
        /// <summary>
        /// this method is only used if the player does a speciffic thing
        /// </summary>
        public void hallway2()
        {
            string mailChoice;
            string hallwayChoice;
            Console.WriteLine("You are in the hallway. You can check the mail, go to the living room or go upstairs");
            hallwayChoice = Console.ReadLine();
            if (hallwayChoice.ToLower() == "check te mail")
            {

                Console.WriteLine("You seem to have gotten a letter from a company named: InGen.");
                Console.WriteLine("Do you want to read the letter or do you want to put it away?");
                mailChoice = Console.ReadLine();
                if (mailChoice.ToLower() == "read")
                {
                    Console.Clear();
                    Console.WriteLine("You spilled your coffee on the letter, it is now unreadable.");
                    System.Environment.Exit(0);



                }
            }
            else if (hallwayChoice.ToLower() == "living room")
            {
                roomChoices();
            }
            else if (hallwayChoice.ToLower() == "go upstairs")
            {
                upstairs();
            }
        }
        /// <summary>
        /// this method is used when the player chooses to go to the kitchen 
        /// </summary>
        public void kitchen()
        {
            string kitchenChoice;

            Console.WriteLine("You are now in the kitchen. ");
            Console.WriteLine("You can make a cup of coffee, make food or go back to the living room.");
            kitchenChoice = Console.ReadLine();
            if (kitchenChoice.ToLower() == "make coffee")
            {
                Console.Clear();

                kitchenChoiceCoffee();
            }
            else if (kitchenChoice.ToLower() == "make food")
            {
                Console.Clear();
                Console.WriteLine("You are now in the kitchen.");
                kitchenChoiceFood();
            }
            else if (kitchenChoice.ToLower() == "go back")
            {
                Console.Clear();
                Console.WriteLine("You are now in the living room.");
                roomChoices();

            }
            else
            {
                Console.WriteLine("Sorry you can't do that.");
                kitchen();
            }
        }
        /// <summary>
        /// this method is used when the player does a speciffic thing
        /// </summary>
        public void kitchenChoiceCoffee()
        {
            string coffeeUse;
            string whereTo;
            string whereTo_2;
            Console.WriteLine("You made a nice cup off coffe. You can drink it or take it with you.");
            coffeeUse = Console.ReadLine();
            if (coffeeUse.ToLower() == "drink it")
            {
                Console.WriteLine("You can make food or go back to the living room");
                whereTo = Console.ReadLine();
                if (whereTo.ToLower() == "go back")
                {
                    Console.WriteLine("You are in the living room. You can go to the kitchen or the hallway.");
                    whereTo_2 = Console.ReadLine();
                    if (whereTo_2.ToLower() == " hallway") { }
                    hallway();

                }
                else if (whereTo.ToLower() == "make food")
                {
                    kitchenChoiceFood();
                }
            }
            else if (coffeeUse.ToLower() == "take it")
            {
                Console.WriteLine("You can make food or go back to the living room");
                whereTo = Console.ReadLine();
                if (whereTo.ToLower() == "go back")
                {
                    Console.WriteLine("You are in the living room. You can go to the kitchen or the hallway.");
                    whereTo_2 = Console.ReadLine();
                    if (whereTo_2.ToLower() == " hallway")
                    {
                        hallway2();

                    }
                }

            }

        }
        /// <summary>
        /// this method is used when the player does a speciffic thing
        /// </summary>
        public void kitchenChoiceFood()
        {
            Console.WriteLine("You made some nice ravioli.\n You ate the ravioli.");
            Console.WriteLine("You can make coffee or go back to the living room ");
            kitchen();
        }
        public void upstairs()
        {
            Console.WriteLine("Your upstairs area is nothing more then a bedroom so you go back down.");
            Console.ReadKey();
            hallway();
        }




    }
}

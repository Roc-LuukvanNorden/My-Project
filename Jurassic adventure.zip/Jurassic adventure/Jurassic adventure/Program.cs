﻿namespace Jurassic_adventure
{
    internal class Program
    {public static places P = new places();
        
        static void Main(string[] args)
        {
            Program p = new Program();

           
            p.start();

            
        }

        /// <summary>
        /// this method starts the game and holds alle needed files to run the game.
        /// </summary>
        void start()
        {
            
            
            Jurassic_Park1 house = new Jurassic_Park1();
            Jurassic_Park1P2 costaRica = new Jurassic_Park1P2();
            Visitor_Center visitor_Center= new Visitor_Center();
            string gameStart;
            Console.WriteLine("Hello and welcome to Jurassic Park the Untold Story. \n In this game we tell you the story off the Jurassic movies from the perspective \n of Doctor Henry Wu, the decisions you make will be vital for how this game turn's out. \n Now you know what this game is about you are ready to get into the game. \n please type start to start or exit to stop");
            gameStart = Console.ReadLine();
            if(gameStart== "start") 
            {
              
                house.game();

                costaRica.costaRica();
                visitor_Center.Visitor_center();
            }
            else if(gameStart== "exit")
            {
                System.Environment.Exit(0);
            }
            else
            {
                Console.WriteLine("Sorry I didn't understand you, could you say that aigan?");
                Console.Clear();
                start();
            }
        }






        
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Visitor_Center
    {
        public bool binders;
        public bool keycard;
        public bool usb_Stick;
      
        string playerlocation;
       
        
        Jungle jungles = new Jungle();// this command is used to link two classes so that i can use methods from the other class
        Random rnd = new Random();//random number generator for random encounters
        
        /// <summary>
        /// this method is used when the player gets to the visitor center
        /// </summary>
        public void Visitor_center()
        {
            East_Dock Dock = new East_Dock();// this command is used to link two classes so that i can use methods from the other class
            Tools Tools = new Tools();
            Console.Clear();

            Raptor_Paddock Raptor_Paddock = new Raptor_Paddock();


            Tools.print("You are now in the visitor center you can stay inside or go outside.");
            playerlocation = Console.ReadLine();
            if (playerlocation.ToLower() == "stay inside")
            {
                Visitor_Center_inside();

            }
            else if (playerlocation.ToLower() == "go outside")
            {
                Console.Clear();
                Tools.print("You are now at the visitor center you can go North, SOuth, East , West or go back inside.");
                playerlocation = Console.ReadLine();
                switch (playerlocation.ToLower())
                {
                    case "north":
                        StaffCenter();
                        break;
                    case "south":
                        Raptor_Paddock.Raptor_Cage();
                        break;
                    case "east":
                        Tools.print("You have found the East Dock. (Press any button to enter.)");
                        Dock.Dock();
                        break;
                    case "west":
                        jungles.Jungles();
                        break;
                    case "go back":
                        Visitor_Center_inside();
                        break;
                }
            }
            else
            {
                Tools.print("I am sorry I did not understand that can you please try again?");
                Console.ReadKey();
                Visitor_center();
            }


        }
        /// <summary>
        /// this method is used when the player gets inside the visitor center
        /// </summary>
        public void Visitor_Center_inside()
        {
            Tools Tools= new Tools();
            Console.Clear();

            Tools.print("You are now inside the visitor center. You can go to the lab, the control room or go outside");
            playerlocation = Console.ReadLine();
            switch (playerlocation.ToLower())
            {
                case "lab":
                    
                    if (rnd.Next(11) == 5)
                    {
                        Tools.print("You go towards the lab but get suprised by raptors you quickly run back and escape, it looks like you need to find a other way around. (Press any butten to continue)");
                        Console.ReadKey();
                        Visitor_center();
                    }
                    else
                    {
                        Tools.print("It looks like this way is blocked turn around and find a different way. (Press any button to continue)");
                        Console.ReadKey();
                        Visitor_center();
                    }
                    break;

                case "control room":
                    ControlRoom();
                    break;

                case "go outside":
                    Visitor_center();
                    break;



            }


        }
        /// <summary>
        /// this method is used when the player gets to the control room
        /// </summary>
        public void ControlRoom()
        {
            
            Tools Tools = new Tools();
            Console.Clear();
            string desks;
            Tools.print("You are now in the control room. You think to renember you left a USB_Stick here you need that to transfer some computer data.\n Look arround to find the USB, it is either on Ray Arnold's desk, Rafael Alcazabrada's desk or on Robert Muldoon's Desk. (Type One for Ray's desk, 2 for Rafael's desk or 3 for Robert's desk");
            desks = Console.ReadLine();
            switch (desks.ToLower())
            {
                case "1":
                    Tools.print("You look all over Ray Arnold's desk but it is not here.(Press any key to continue looking)");
                    Console.ReadKey();
                    ControlRoom();
                    break;
                case "2":
                    usb_Stick = true;
                    Tools.print("You look at Rafael Alcazabrada's desk and see it laying there right away. You feel kinda dumb for not seeing it sooner.(Press any key to go to the main hall.)");
                    Console.ReadKey();
                    Visitor_Center_inside();
                    break;

                case "3":
                    Tools.print("You look all over Robert Muldoon's desk but it is not here.(Press any key to continue looking)");
                    Console.ReadKey();
                    ControlRoom();
                    break;
            }
        }
        /// <summary>
        /// this method is used when the player reaches the staff center
        /// </summary>
        public void StaffCenter()
        {
            Tools Tools = new Tools();
            Console.Clear();
            Tools. print("You have found the staff center, you can go inside or stay outside");
            playerlocation = Console.ReadLine();
            if (playerlocation.ToLower() == "go inside")
            {
                
                StaffCenter_Inside();
            }
            else if (playerlocation.ToLower() == "stay outside")
            {
                Console.Clear();
                Tools.print("You are now at the staff center you can go North, South, East , West or go inside.");
                playerlocation = Console.ReadLine();
                switch (playerlocation.ToLower())
                {
                    case "north":
                        jungles.Jungles();
                        break;
                    case "south":
                        Visitor_center();
                        break;
                    case "east":
                        Tools.print("No just no! Why would you go into the jungle just go back. (Press any key to go back)");
                        StaffCenter();
                        break;
                    case "west":
                        jungles.Jungles();
                        break;
                    case "go back":
                        Visitor_center();
                        break;
                }
            }
            else
            {
                Tools.print("I am sorry I did not understand you can you try again? (Press any button to continue)");
                Console.ReadKey();
                StaffCenter();
            }



        }
        /// <summary>
        /// this method the starts when the player gets inside the staff center
        /// </summary>
        public void StaffCenter_Inside()
        {
            
            Tools Tools = new Tools();
            Console.Clear();
            Tools.print("You are inside the staff center you can go back outside or stay inside.");
            playerlocation = Console.ReadLine();
            if (playerlocation.ToLower() == "stay inside")
            {
                Console.Clear();
                Tools.print("You are inside from here you can go to the: staff room, the dressing room or the cafetaria.");
                playerlocation = Console.ReadLine();
                if (playerlocation.ToLower() == "staff room")
                {
                    
                    if(rnd.Next(11) == 5)
                    {
                        Console.Clear();
                        Tools.print("You enter the staff and get suprised by a pack of Dilophosaurusus. You can't make it out and suffer a terrible faith.");
                        Console.ReadKey();
                        System.Environment.Exit(0);
                    }
                    else
                    {
                        binders = true;
                        Console.Clear();
                        Tools.print("You enter the staff room and apperently think it is a good time to make a cup off coffee.\n While drinking the coffe you see one of your binders you decide to take it with you. (Press any key to continue)");
                        Console.ReadKey();
                        StaffCenter();
                    }
                }
                else if((playerlocation.ToLower() == "dressing room"))
                {
                    Console.Clear();
                    Tools.print("As you enter the dressing room you see a keycard laying on a bench, you need that to gain acces to the lab. Do you wish to pick it up?");
                    string pick_Up= Console.ReadLine();
                    while (pick_Up.ToLower() != "yes")
                    {
                        Console.Clear();
                        Tools.print("Just pick it up, I said you needed it.");
                         pick_Up = Console.ReadLine();
                    }
                    keycard = true;
                    Tools.print("Good job on picking that up, you now have acces to the lab.");
                    StaffCenter_Inside();
                }
                else if(playerlocation.ToLower() == "cafetaria")
                {
                    Console.Clear();
                    Tools.print("Why are you in the cafetaria it is not exactly a good time to make lunch, just go back oke? (Press any button to go back)");
                    Console.ReadKey();
                    StaffCenter_Inside();
                }

            }
            else if (playerlocation.ToLower() == "go outside")
            {
                StaffCenter();
            }

        }


    }

}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{


    public class places
    {
        public bool desk;
        public bool binder;
        public bool cabinet;


        public bool lab;
        public bool office;
        public bool staff_room;
     




    }

}

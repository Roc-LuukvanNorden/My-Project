﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Tools
    {

        /// <summary>
        /// this method is used to slowprint text
        /// </summary>
  
        public void print(string text, int speed = 70)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                System.Threading.Thread.Sleep(speed);// this command is so that the letters delay as musch as i said with the int speed
            }
            Console.WriteLine();
        }

    }
}

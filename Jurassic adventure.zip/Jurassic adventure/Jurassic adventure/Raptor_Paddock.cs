﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Raptor_Paddock
    {/// <summary>
    /// just runs this part of the game
    /// </summary>
        public void Raptor_Cage()
        {
            Tools Tools= new Tools();// makes sure i can use the commands from that class in this one
            Jungle jungles = new Jungle();//makes sure i can go to a command from that class
            string playerlocation;// string used for userinput on where the player whants to go
            Random rnd = new Random();//random number generator for random scenarios
            int num = rnd.Next(1, 8);
            Visitor_Center visitor_Center = new Visitor_Center();//makes sure i can go to a command from that class
            Labs labs = new Labs();//makes sure i can go to a command from that class
            
            Tools.print("* You are now at the Raptor_Paddock*");
            if (num == 5)
            {
                Tools.print("You arived at the wrong time the raptors just broke out and attacked you. You did not survive the attack.");
                System.Environment.Exit(0);// closes the game

            }
            else if (num == 6)
            {
                Tools.print("Oh no the raptor fencing is broken it looks like they have escaped better be carefull from now on.");
                playerlocation = Console.ReadLine();
                switch (playerlocation.ToLower())//this switch gives multiple direction options
                {
                    case "north":
                        visitor_Center.Visitor_center();

                        break;
                    case "south":
                        jungles.Jungles();
                        break;
                    case "east":
                        Tools.print("Congratulations you found the back entrance to the visitor center from here you can enter the labs.(Press any key to enter)");
                        Console.ReadKey();
                        labs.Labratory();

                        break;
                    case "west":
                        jungles.Jungles();
                        break;
                }
            }
            else
            {
                Tools.print("You arive at the raptor paddock it looks like the raptors are still inside since the fences are still in tact. \n From this location you can go North, West, South or East");
                playerlocation = Console.ReadLine();
                switch (playerlocation.ToLower())
                {
                    case "north":
                        visitor_Center.Visitor_center();
                        
                        break;
                    case "south":
                        jungles.Jungles();
                        break;
                    case "east":Tools.print("Congratulations you found the back entrance to the visitor center from here you can enter the labs.(Press any key to enter)");
                        Console.ReadKey();
                        labs.Labratory();

                        break;
                    case "west":
                        jungles.Jungles();
                        break;
                }

            }


        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Jungle
    {
        /// <summary>
        /// this method is used when the player wanders of in the jungle
        /// </summary>
        public void Jungles()
        {
            Visitor_Center visitor_Center = new Visitor_Center();// this command is used to link two classes so that i can use methods from the other class
            Console.Clear();
            string playerlocation;
            Raptor_Paddock Raptor_Paddock = new Raptor_Paddock();// this command is used to link two classes so that i can use methods from the other class

            Tools Tools = new Tools();
            Tools.print("You are in the jungle, are you sure you want to be here? It is a dangerous place and there is also nothing to do here.\n From this location you can go North, West, South or East");

            playerlocation = Console.ReadLine();
            switch (playerlocation.ToLower())
            {
                case "north":
                    Raptor_Paddock.Raptor_Cage();

                    break;
                case "south":
                    Island_Edge();
                    break;
                case "east":
                    Tools.print("You are still in the jugnle, what you thought this was a small island? Nuh-uh it is pretty big but hey if you continue this way you might find something.\n From this location you can go North, West, South or East");
                    playerlocation = Console.ReadLine();
                    switch (playerlocation.ToLower())
                    {
                        case "north":
                            Tools.print("Congratulations you found a emergency shelter you can take cover here if needed.");

                            break;
                        case "south":
                            Island_Edge();
                            break;
                        case "east":
                            Tools.print("Congratulations you have found the power generator if you whant to you can turn it back on");
                            string power_Generator = Console.ReadLine();
                            if(power_Generator == "turn it on")
                            {
                                Tools.print("Congratulations you found a secret ending, you were able to turn on the power the systems are now back online.\n Now InGen can get Jurassic Park opperational again and you probably get a promotion for saving their park");
                                System.Environment.Exit(0);

                            }
                            else
                            {
                                Console.WriteLine("Yeah you are right who needs power anyway.");
                                Tools.print("You turn back to the raptor paddock in the hope to find something else. (Press any key to continue)");
                                Console.ReadKey();
                                Raptor_Paddock.Raptor_Cage();

                            }

                            break;
                        case "west":Tools.print("You are back right where you just were you aren't lost are you?");
                            Jungles();
                            break;
                    }
                    break;
                case "west":
                    Tools.print("You are in a random place in the jungle what are you doing? just go back to the visitor center. *Game developer: You know what I will give you a hand, just press any key to go to the visitor center*");
                    Console.ReadKey();
                    visitor_Center.Visitor_center();

                    break;
            }
            
        }
        /// <summary>
        /// this method is used when the player walks to far into the jungle
        /// </summary>
        public void Island_Edge()
        {
            Visitor_Center visitor_Center = new Visitor_Center();
            Console.Clear();
            Tools Tools = new Tools();
            string playerlocation;
            Tools.print(" Oke well done you have walked all the way to the end of the island what do you wanna do now huh?");
            playerlocation = Console.ReadLine();
            switch (playerlocation.ToLower())
            {
                case "north":
                    Jungles();

                    break;
                case "south":
                    Tools.print("Hey you are already at the edge if you go any further you are gonna go swiming just go any other way it is not that hard.");
                    playerlocation = Console.ReadLine();
                    switch (playerlocation)
                    {
                        case "north":
                            Island_Edge();

                            break;
                        case "south":
                            Tools.print("Stop trying to go south! You know what i had enough of this.");
                            System.Environment.Exit(0);
                            break;
                        case "east":
                            Tools.print("You are in a random place in the jungle what are you doing? just go back to the visitor center. *Game developer: You know what I will give you a hand, just press any key to go to the visitor center*");
                            Console.ReadKey();
                            visitor_Center.Visitor_center();
                            break;
                        case "west":
                            Tools.print("You are in a random place in the jungle what are you doing? just go back to the visitor center. *Game developer: You know what I will give you a hand, just press any key to go to the visitor center*");
                            Console.ReadKey();
                            visitor_Center.Visitor_center();
                            break;
                    }
                    break;
                case "east":
                    Tools.print("You are in a random place in the jungle what are you doing? just go back to the visitor center. *Game developer: You know what I will give you a hand, just press any key to go to the visitor center*");
                    Console.ReadKey();
                    visitor_Center.Visitor_center();
                    break;
                case "west":
                    Tools.print("You are in a random place in the jungle what are you doing? just go back to the visitor center. *Game developer: You know what I will give you a hand, just press any key to go to the visitor center*");
                    Console.ReadKey();
                    visitor_Center.Visitor_center();
                    break;
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Jurassic_Park1P2
    {
        Tools T = new Tools();
        public void costaRica()
        {
            Jurassic_Park1P3 Isla_Sorna = new Jurassic_Park1P3();
            string question1;
            string question2;
            string contract= File.ReadAllText("contract.txt");
           
           
           
;
           
            Console.Clear();
            Console.WriteLine("*You arive at Costa Rica and head to InGen's main facility.\n When you arive you see a short elderly man dressed fully in white.*\n You: Pardon me is this the InGen facility?\n (Unknown stranger): Yes yes, how can i help you?\n You: I needed to come here for some job information.\n (Unknown stranger): Ah yes yes, you must be Dr.Wu. \n You: Yes and you are? \n (Unknown stranger): Ah yes, I forgot i haven't introduced myself, my name is John hammond.\n You: Well nice to meet you.\n John Hammond: Yes yes, the pleasure is al mine. Well shall we get inside?");
            question1= Console.ReadLine();
            if (question1.ToLower() == "yes")
            {
                Console.WriteLine("You: After you.\n *You go inside. \n *You follow Hammond to a room that kind of looks like a living room.*\n John Hammond: Please take a seat Henry.\n *You take a seat.*\n John Hammond: Well shall we begin?\n You: Ehm begin what?\n John Hammond: Well setting up the contract ofcourse. In this paper is all you need to know.( Press any key to continue.)");
                Console.ReadKey();
                Console.Clear();
                Console.WriteLine(contract);
                Console.WriteLine("(Press any key to continue.)");
                Console.ReadKey();
                Console.Clear();
                Console.WriteLine("John Hammond: Oh and one more thing before I tell you what you will be doing you need to sign a non-diclosureagreement.\n You: Really why is that?\n John Hammond: Oh it is just safetey porcautions, my lawyers said that it was necesary.");
                Console.WriteLine("You (thinking): (1. Hmm that is kind of suspicious.) (2.Well if his lawyers said it was necesary then i must be needed.)");
                question2= Console.ReadLine();
                switch (question2)
                {
                    case "1":
                        Console.Clear();
                        Console.WriteLine("You: I am sorry, I find this a bit suspicious.\n John Hammond: Oh no no, I asure you it is olny because my lawyers think it is needed.\n You: Yeah no I am sorry I am not gonna do this, goodbye.");
                        System.Environment.Exit(0);


                        break;
                    case "2": Console.WriteLine("You:Sure I will sign it. \n John Hammond: Exelent, you will not regret your choice I asure you.\n * You sign the paper*\nJohn Hammond: Well then let's get to work, oh one more thing you won't be working here.\n You: What, where will i be working?\n John Hammon: I will show you, come along.\n*You follow Hammond to a heli pad*\n You: Where will we be going\n John Hammond: I own a island 207 miles west of Costa Rica that is where we will be going.\n * You and Hammond get in the chopper and take off.*");
                        Console.WriteLine("Press any key to continue");
                        Console.ReadKey();
                        Console.Clear();
                        Isla_Sorna.islaSorna();

                        break; 
                }




                Console.ReadKey();
                Console.Clear();
                Console.WriteLine();
            }
            else if(question1.ToLower() == "no")
            {
                Console.WriteLine("No sorry I am not intrested anymore.");
                System.Environment.Exit(0);
            }
        }


        

    }
}

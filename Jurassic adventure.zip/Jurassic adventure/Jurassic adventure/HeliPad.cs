﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class East_Dock
    {




        /// <summary>
        /// this method is used when the player gets a certain erea
        /// </summary>
        public void Dock()
        {
            Visitor_Center visitor_Center = new Visitor_Center();
            Items Items = new Items();
            Tools Tools = new Tools();
            if (Items.computer_Data == false || visitor_Center.binders == false)
            {
                Tools.print("I am sorry you haven't collected al your research so you can't leave yet.");
                visitor_Center.Visitor_center();
            }
            else
            {
                Tools.print("*Congratulations you collected all you research and can now leave* Congrats on beating my game,\n Regards Luuk van Norden ");
                System.Environment.Exit(0);
            }
        }
    }
}

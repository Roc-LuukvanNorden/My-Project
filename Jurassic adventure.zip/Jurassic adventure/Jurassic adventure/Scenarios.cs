﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class Scenarios
    {
        Tools Tools = new Tools();



        DNA_Sequence DNA = new DNA_Sequence();

       /// <summary>
        /// this method is used when the player chooses potoo DNA
        /// </summary> 
        public void PotooDNA()
        {
            Console.Clear();
            Tools.print("You choose potoo DNA, the sequence was..... SUCESSFULL!\n *video pops up* Dr.Levi: Congratulations you had your first succesfull sequence.\n Now use the DNA to make a embryo and put it in a unfurtilized ostrich egg to make sure it survives. This sequence takes a few weeks so you can enjoy the island while you wait for the result.");
            Tools.print("*A few weeks later* ");
            Console.WriteLine("The eggs are ready to hatch so you go to the incubation room, you arive just in time a egg is about to hatch. Suddenly one of the eggs starts to crack and a little bird head pops out, you look in confusion at the bird. It turns out using bird DNA and a bird egg just makes a normal bird. Well time to try aigain. (Press any key to continue)");
            Console.ReadKey();
            DNA.DNA();
        }
        /// <summary>
        /// this method is used when the player chooses frog DNA
        /// </summary> 
        public void FrogDNA()
        {
            Console.Clear();
            Tools.print("You choose frog DNA, the sequence was..... SUCESSFULL!\n *video pops up* Dr.Levi: Congratulations you had your first succesfull sequence.\n Now use the DNA to make a embryo and put it in a unfurtilized ostrich egg to make sure it survives. This sequence takes a few weeks so you can enjoy the island while you wait for the result.");
            Tools.print("*A few weeks later* ");
            Console.WriteLine(" The eggs are ready to hatch so you go to the incubation room, you arive just in time a egg is about to hatch. Suddenly one of the eggs starts to crack and a little dinosaur head pops out, you are amazed with the sight of the little dinosaur and celebrate with your colleagues in celebration of this little dino. Then the next morning you wake up to the phone ringing.\n(do you pick up the phone or let it ring?) ");
            string phone = Console.ReadLine();
            if (phone == "pick up")
            {
                Console.WriteLine("John Hammond: Hello Henry, I heard you had succes with the incubation concratulations.\n You: thank you sir the team did their best job and it paid off.\n John Hammmond: Good good I am glad, but i did not only call you to congratulate you, \nno I want you to come work on Isla Nublar from now on, so that we can create dinosaurs on both islands.\n All the tools and other stuff you need is here I spared no expense.\n You: Alright sir I will be there tommorrow. ");
                Tools.print("* Five years passed since you arived at Isla Nublar. The park is now opperatinal but not finnished yet, unfortunatly the building is delayed due to a terrible accident. Hammond has asked some people to inspect his park there names are: Ellie Settler, Ian Malcom, Alan Grant and the InGen lawyer Donald Gennaro. However during the inpection somethings went terribly wrong, a storm rolled in and a coworker sabotaged all the fences the dinosaurs are now loose. Your only escape is the boot at the east doc but you don't want your discorvery to get lost so you need to gather a few items before you can leave. (Press any key to continue)*");
                Console.ReadKey();
            }
            else if (phone == "let it ring")
            {
                Tools.print("Congratulations you didn't respond to the phone call you are now fired.");
                System.Environment.Exit(0);
            }

        }
        /// <summary>
        /// this method is used when the player chooses fish DNA
        /// </summary> 
        public void FishDNA()
        {
            Console.Clear();
            Tools.print("You choose fish DNA, the sequence was..... SUCESSFULL!\n *video pops up* Dr.Levi: Congratulations you had your first succesfull sequence.\n Now use the DNA to make a embryo and put it in a unfurtilized ostrich egg to make sure it survives. This sequence takes a few weeks so you can enjoy the island while you wait for the result.");
            Tools.print("*A few weeks later* ");
            Console.WriteLine("  The eggs are ready to hatch so you go to the incubation room, you arive just in time a egg is about to hatch.\n *egg hatches* The eggshell is broken and a little dino head pops out but it looks wierd almost like it is dying, when you look closer you realise it has gills because of the fish DNA, when the rest of the eggs hatch you see they all have that problem.\n None of the hattchlings survived it is sad but you now know what you did wrong. Well it is time to start over. (Press any button to continue)");

            Console.ReadKey();
            DNA.DNA();
        }
        /// <summary>
        /// this method is used when the player chooses lizard DNA
        /// </summary> 
        public void LizardDNA()
        {
            Console.Clear();
            Tools.print("You choose lizard DNA, the sequence was..... UNSUCSESSFULL! \n *video pops up* Dr.Levi:It is a shame but sometimes this happens, time to get back to sequincing.(Press any button to continue)");
            Console.ReadKey();
            DNA.DNA();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jurassic_adventure
{
    internal class DNA_Sequence
    {
        
        
        public DNA_Sequence()
        {

        }
        public void DNA()
        {
            Tools Tools = new Tools();
            Scenarios Scenario = new Scenarios();// this command is used to link two classes so that i can use methods from the other class
            Console.Clear();
            string dnaChoice;
          
            Console.WriteLine("* You have lookded evrewhere so you decide to boot up the computer and fill in the password you found. When the computer starts you see a application called DNA sequence you open it. Suddenly a video starts playing.*");
            Tools.print("Hello Henry, let me introduce myself my name is Dr.Levi Feunekes, if you see this video you have opend the DNA_Sequence and I am here to explain this to you.\n After this video the computer will loop trough a Dna Streng until a gap is found then it is your job to fill the gap with the available DNA. I wish you the best off luck.");
            Tools.print("(Press any key to start the program.)");
            Console.ReadKey();
            
            Console.Clear();
            string dnaCode = File.ReadAllText("Dna_Code.txt");//outputs a textfile with dna code
            Tools.print(dnaCode,15);// the 15 is the speed at which this file gets  printed
            Tools.print("A gap is found, we have four options to replace the DNA with:\n Potoo DNA: CCTGTCGTTG AG.\n Frog DNA: CACATGGACGCGT.\n Fish DNA: GCGTTGCTGGCGT.\n Lizard DNA:GTGGCGAAACCCG.");
            dnaChoice = Console.ReadLine();
            switch (dnaChoice.ToLower())
            {
                case "potoo":
                    Scenario.PotooDNA();
                    break;
                case "frog":
                    Scenario.FrogDNA();
                    break;
                case "fish":
                    Scenario.FishDNA();
                    break;
                case "lizard":
                    Scenario.LizardDNA();
                    break;
            }
        }


    }
}
